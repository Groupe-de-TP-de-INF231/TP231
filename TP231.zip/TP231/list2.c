#include <stdio.h>
#include <stdlib.h>

// Structure pour une liste simplement chainee
struct List{
    int val;
    struct List *suiv;
};
typedef struct List *listc;

// Structure pour une liste doublement chainee
struct Dlist{
    struct Dlist *prec;
    int val;
    struct Dlist *suiv;
};
typedef struct Dlist *listdc;

// Structure pour une liste simplement chainee circulaire
struct Clist{
    int val;
    struct Clist *suiv;
};
typedef struct Clist *listcc;

// Nouvelle structure pour une liste doublement chainee circulaire
struct CDlist{
    struct CDlist *prec;
    int val;
    struct CDlist *suiv;
};
typedef struct CDlist *listdcc; // Typedef pour liste doublement circulaire

// Affiche une liste simplement chainee
void aff(listc L){
    if (L == NULL) {
        printf("NULL\n");
        return;
    }
    listc P = L;
    while(P != NULL){
        printf("%d -> ",P->val);
        P = P->suiv;
    }
    printf("NULL\n");
}

// Affiche une liste doublement chainee
void affi(listdc L){
    if (L == NULL) {
        printf("NULL <-> NULL\n");
        return;
    }
    listdc P = L;
    printf("NULL <-> ");
    while(P != NULL){
        printf("%d <-> ",P->val);
        P = P->suiv;
    }
    printf("NULL\n");
}

// Affiche une liste simplement chainee circulaire
void affic(listcc L) {
    if(L == NULL) {
        printf("NULL\n");
        return;
    }
    printf("Header -> ");
    listcc P = L;
    do {
        printf("%d -> ",P->val);
        P = P->suiv;
    } while(P != L);
    printf("Header\n");
}

// Affiche une liste doublement chainee circulaire
void affidc(listdcc L) {
    if (L == NULL) {
        printf("NULL\n");
        return;
    }
    listdcc P = L;
    printf("Header <-> ");
    do {
        printf("%d <-> ", P->val);
        P = P->suiv;
    } while (P != L);
    printf("Header\n");
}

// Insere un element dans une liste simplement chainee triee
listc insert_lsct(listc L, int a){
    listc P = (listc)malloc(sizeof(struct List));
    if (P == NULL) {
        printf("Erreur d'allocation memoire.\n");
        return L;
    }
    P->val = a;
    P->suiv = NULL;

    if(L == NULL || a < L->val){     
        P->suiv = L;
        L = P;
        return L;
    }
    listc V = L;
    while(V->suiv != NULL && V->suiv->val < a){
        V = V->suiv;
    }
    P->suiv = V->suiv;
    V->suiv = P;
    return L;
}

// Supprime toutes les occurrences d'un element dans une liste simplement chainee
listc supp_elmt(listc L, int a){
    if(L == NULL)
        return NULL;

    // Supprimer les elements en tete de liste
    while (L != NULL && L->val == a) {
        listc temp = L;
        L = L->suiv;
        free(temp);
    }

    if (L == NULL) // La liste est vide apres suppression de la tete
        return NULL;

    listc current = L;
    while (current->suiv != NULL) {
        if (current->suiv->val == a) {
            listc temp = current->suiv;
            current->suiv = current->suiv->suiv;
            free(temp);
        } else {
            current = current->suiv;
        }
    }
    return L;
}

// Insere un element dans une liste doublement chainee triee
listdc insert_listdc(listdc L, int a){
    listdc T = (listdc)malloc(sizeof(struct Dlist));
    if (T == NULL) {
        printf("Erreur d'allocation memoire.\n");
        return L;
    }
    T->val = a;
    T->suiv = NULL;
    T->prec = NULL;

    if(L == NULL || L->val > a){
        T->suiv = L;
        if (L != NULL) {
            L->prec = T;
        }
        L = T;
        return L;
    }
    listdc P = L;
    while(P->suiv != NULL && P->suiv->val < a){
        P = P->suiv;
    }
    T->suiv = P->suiv;
    T->prec = P;
    if (P->suiv != NULL) {
        P->suiv->prec = T;
    }
    P->suiv = T;
    return L;
}

// Cree un nouveau noeud pour une liste simplement circulaire
listcc creer_listcc(int a) {
    listcc P = (listcc)malloc(sizeof(struct Clist));
    if(!P) {
        printf("Erreur d'allocation de memoire\n");
        return NULL;
    }
    P->val = a;
    P->suiv = NULL; // Sera ajuste lors de l'insertion
    return P;
}

// Insere un element en queue dans une liste simplement chainee circulaire
listcc insert_listcc_queue(listcc L , int a){
    listcc P = creer_listcc(a);
    if (P == NULL) return L; // Erreur d'allocation

    if(L == NULL) {
        L = P;
        P->suiv = L; // Pointeur vers lui-meme
        return L;
    } else {
        listcc V = L;
        while(V->suiv != L) { // Trouver le dernier element
            V = V->suiv;
        }
        V->suiv = P;
        P->suiv = L;
        return L; 
    }     
}

// Insere un element en tete dans une liste simplement chainee circulaire
listcc insert_listcc_tete(listcc L, int a){
    listcc P = creer_listcc(a);
    if (P == NULL) return L; // Erreur d'allocation

    if(L == NULL) {
        L = P;
        P->suiv = L;
        return L;
    } else {
        listcc V = L;
        while(V->suiv != L) { // Trouver le dernier element
            V = V->suiv;
        }
        P->suiv = L; // Le nouveau noeud pointe vers l'ancienne tete
        V->suiv = P; // Le dernier noeud pointe vers la nouvelle tete
        L = P;      // L devient la nouvelle tete
        return L; 
    }     
}

// -------------------------------------------------------------------
// NOUVELLES FONCTIONS POUR LISTE DOUBLEMENT CHAÎNÉE CIRCULAIRE (listdcc)
// -------------------------------------------------------------------

// Cree un nouveau noeud pour une liste doublement circulaire
listdcc creer_listdcc(int a) {
    listdcc P = (listdcc)malloc(sizeof(struct CDlist));
    if (!P) {
        printf("Erreur d'allocation de memoire\n");
        return NULL;
    }
    P->val = a;
    P->suiv = NULL;
    P->prec = NULL;
    return P;
}

// Insere un element en tete dans une liste doublement chainee circulaire
listdcc insert_listdcc_tete(listdcc L, int a) {
    listdcc P = creer_listdcc(a);
    if (P == NULL) return L;

    if (L == NULL) {
        L = P;
        L->suiv = L;
        L->prec = L;
    } else {
        P->suiv = L;
        P->prec = L->prec;
        L->prec->suiv = P;
        L->prec = P;
        L = P;
    }
    return L;
}

// Insere un element en queue dans une liste doublement chainee circulaire
listdcc insert_listdcc_queue(listdcc L, int a) {
    listdcc P = creer_listdcc(a);
    if (P == NULL) return L;

    if (L == NULL) {
        L = P;
        L->suiv = L;
        L->prec = L;
    } else {
        P->suiv = L;
        P->prec = L->prec;
        L->prec->suiv = P;
        L->prec = P;
    }
    return L;
}

// Supprime toutes les occurrences d'un element dans une liste doublement chainee circulaire
listdcc supp_elmt_dcc(listdcc L, int a) {
    if (L == NULL) return NULL;

    listdcc current = L;
    int initial_size = 0;
    if (L != NULL) { // Compter le nombre d'éléments initial pour éviter boucle infinie si L devient NULL
        listdcc temp_count = L;
        do {
            initial_size++;
            temp_count = temp_count->suiv;
        } while (temp_count != L);
    }
    int count = 0; // Nombre d'elements deja traites

    do {
        listdcc next_node = current->suiv; // Stocker le suivant avant liberation
        if (current->val == a) {
            if (current == L) { // Si c'est la tete
                if (L->suiv == L) { // Le seul element
                    free(L);
                    return NULL;
                }
                L->prec->suiv = L->suiv;
                L->suiv->prec = L->prec;
                L = L->suiv; // Nouvelle tete
                free(current);
            } else { // Pas la tete
                current->prec->suiv = current->suiv;
                current->suiv->prec = current->prec;
                free(current);
            }
        }
        current = next_node;
        count++;
        // Si la liste est devenue vide ou si tous les noeuds originaux ont ete parcourus
        if (L == NULL || (current == L && count >= initial_size)) break;

    } while (current != L && count < initial_size + 1); // +1 pour s'assurer de passer par le dernier si modifié

    // Cas où la liste devient vide (par ex. tous les éléments sont supprimés)
    if (initial_size > 0 && L == NULL) return NULL; 
    
    // Une verification finale si le seul element restant est 'a' et n'a pas ete supprime
    if (L != NULL && L->suiv == L && L->val == a) {
        free(L);
        return NULL;
    }

    return L;
}


// -------------------------------------------------------------------
// Fonctions de LIBERATION DE MEMOIRE
// -------------------------------------------------------------------

// Supprime une liste simplement chainee et libere la memoire
void free_listc(listc L) {
    listc current = L;
    while (current != NULL) {
        listc next = current->suiv;
        free(current);
        current = next;
    }
}

// Supprime une liste doublement chainee et libere la memoire
void free_listdc(listdc L) {
    listdc current = L;
    while (current != NULL) {
        listdc next = current->suiv;
        free(current);
        current = next;
    }
}

// Supprime une liste simplement chainee circulaire et libere la memoire
void free_listcc(listcc L) {
    if (L == NULL) return;
    listcc current = L->suiv;
    while (current != L) {
        listcc next = current->suiv;
        free(current);
        current = next;
    }
    free(L); // Liberer le dernier element (la tete)
}

// Supprime une liste doublement chainee circulaire et libere la memoire
void free_listdcc(listdcc L) {
    if (L == NULL) return;
    listdcc current = L->suiv;
    while (current != L) {
        listdcc next = current->suiv;
        free(current);
        current = next;
    }
    free(L); // Liberer le dernier element (la tete)
}


int main(){
    listc L_simple = NULL;
    listdc L_double = NULL;
    listcc L_circulaire_simple = NULL;
    listdcc L_circulaire_double = NULL; // Nouvelle liste pour le menu 5
    int choix, valeur;
    
    printf("\n-------- TP2 DE INF 231 (LINKED LIST) -------\n");
    
    while(1){
        printf("\nMenu principal :\n");
        printf("1. Inserer dans une liste simple triee\n");
        printf("2. Supprimer toutes les occurrences d'un element dans une liste simple\n");
        printf("3. Insertion d'un element dans une liste doublement chainee triee\n");
        printf("4. Insertion en tete et en queue dans une liste simplement chainee circulaire\n");
        printf("5. Gerer une liste doublement chainee circulaire\n");
        printf("6. QUITTER\n");
        printf("Choix : ");
        if (scanf("%d",&choix) != 1) {
            printf("Entree invalide. Veuillez saisir un nombre.\n");
            while (getchar() != '\n');
            continue;
        }

        switch(choix){
            case 1:
                printf("\n--- Liste simple triee ---\n");
                aff(L_simple);
                printf("Quel nombre voulez-vous inserer ? ");
                if (scanf("%d",&valeur) != 1) {
                    printf("Entree invalide.\n");
                    while (getchar() != '\n');
                    break;
                }
                L_simple = insert_lsct(L_simple, valeur);
                printf("Liste apres insertion : ");
                aff(L_simple);
            break;
            case 2:
                printf("\n--- Suppression dans liste simple ---\n");
                aff(L_simple);
                if (L_simple == NULL) {
                    printf("La liste est vide, rien a supprimer.\n");
                    break;
                }
                printf("Quel nombre voulez-vous supprimer ? ");
                if (scanf("%d",&valeur) != 1) {
                    printf("Entree invalide.\n");
                    while (getchar() != '\n');
                    break;
                }
                L_simple = supp_elmt(L_simple, valeur);
                printf("Liste apres suppression : ");
                aff(L_simple);
            break;
            case 3:
                printf("\n--- Liste doublement chainee triee ---\n");
                affi(L_double);
                printf("Quel nombre voulez-vous inserer ? ");
                if (scanf("%d",&valeur) != 1) {
                    printf("Entree invalide.\n");
                    while (getchar() != '\n');
                    break;
                }
                L_double = insert_listdc(L_double, valeur);
                printf("Liste apres insertion : ");
                affi(L_double);
            break;
            case 4:
                printf("\n--- Liste simplement chainee circulaire ---\n");
                affic(L_circulaire_simple);
                int sub_choix_circulaire_simple;
                printf("1. Insertion en tete\n2. Insertion en queue\nChoix: ");
                if (scanf("%d",&sub_choix_circulaire_simple) != 1) {
                    printf("Entree invalide.\n");
                    while (getchar() != '\n');
                    break;
                }
                printf("Quel nombre voulez-vous inserer ? ");
                if (scanf("%d",&valeur) != 1) {
                    printf("Entree invalide.\n");
                    while (getchar() != '\n');
                    break;
                }
                
                if (sub_choix_circulaire_simple == 1) {
                    L_circulaire_simple = insert_listcc_tete(L_circulaire_simple, valeur);
                } else if (sub_choix_circulaire_simple == 2) {
                    L_circulaire_simple = insert_listcc_queue(L_circulaire_simple, valeur);
                } else {
                    printf("Choix invalide pour l'insertion circulaire simple.\n");
                }
                printf("Liste apres insertion : ");
                affic(L_circulaire_simple);
            break;
            case 5:
                printf("\n--- Liste doublement chainee circulaire ---\n");
                affidc(L_circulaire_double);
                int sub_choix_circulaire_double;
                printf("1. Insertion en tete\n2. Insertion en queue\n3. Suppression d'element\nChoix: ");
                if (scanf("%d",&sub_choix_circulaire_double) != 1) {
                    printf("Entree invalide.\n");
                    while (getchar() != '\n');
                    break;
                }

                if (sub_choix_circulaire_double == 1 || sub_choix_circulaire_double == 2) {
                    printf("Quel nombre voulez-vous inserer ? ");
                    if (scanf("%d",&valeur) != 1) {
                        printf("Entree invalide.\n");
                        while (getchar() != '\n');
                        break;
                    }
                    if (sub_choix_circulaire_double == 1) {
                        L_circulaire_double = insert_listdcc_tete(L_circulaire_double, valeur);
                    } else { // sub_choix_circulaire_double == 2
                        L_circulaire_double = insert_listdcc_queue(L_circulaire_double, valeur);
                    }
                    printf("Liste apres insertion : ");
                    affidc(L_circulaire_double);
                } else if (sub_choix_circulaire_double == 3) {
                    if (L_circulaire_double == NULL) {
                        printf("La liste est vide, rien a supprimer.\n");
                        break;
                    }
                    printf("Quel nombre voulez-vous supprimer ? ");
                    if (scanf("%d",&valeur) != 1) {
                        printf("Entree invalide.\n");
                        while (getchar() != '\n');
                        break;
                    }
                    L_circulaire_double = supp_elmt_dcc(L_circulaire_double, valeur);
                    printf("Liste apres suppression : ");
                    affidc(L_circulaire_double);
                } else {
                    printf("Choix invalide pour la liste doublement chainee circulaire.\n");
                }
            break;
            case 6:
                // Liberer la memoire avant de quitter
                free_listc(L_simple);
                free_listdc(L_double);
                free_listcc(L_circulaire_simple);
                free_listdcc(L_circulaire_double); // Liberer la nouvelle liste
                printf("Merci d'avoir utilise le programme. Au revoir !\n");
                return 0;
            break;
            default:
                printf("Choix invalide. Veuillez reessayer.\n");
            break;
        }   
    }
    return 0;
}